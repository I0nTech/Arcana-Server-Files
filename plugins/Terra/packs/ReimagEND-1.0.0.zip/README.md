# ReimagEND
A Terra pack designed to reimagine the End with new biomes, features, and terrain to explore

Part of this pack uses resources from Astrash's Aeropelago pack, found [here](https://github.com/Astrashh/Aeropelago).

As of Terra version 6.2, there is no easy way to set generators on the Fabric and Forge platform implementations other than the overworld.  
Due to this, the only platform that you can easily use this pack on is the Bukkit version.  Please keep this in mind before creating issues related to the Fabric or Forge platforms.

### This pack is a WORK IN PROGRESS.  It is currently survival ready however it is not feature complete.  Expect frequent changes which may be incompatible (i.e, cause chunk borders) with older versions of the pack.
